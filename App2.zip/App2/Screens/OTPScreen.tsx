import React from 'react';
import OTP from "../modules/otp";

export default function () {
    return(
       <OTP/>
    );
}