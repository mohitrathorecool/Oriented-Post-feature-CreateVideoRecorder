import React from 'react';
import CreateVideo from "../modules/createVideo";

export default function () {
    return(
       <CreateVideo/>
    );
}