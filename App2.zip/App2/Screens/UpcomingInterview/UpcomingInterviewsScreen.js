import React from 'react';
import {
    SafeAreaView,
    StatusBar,
    StyleSheet,
    Text,
    View, Image, FlatList, ScrollView
} from 'react-native';

const DATA = [{ id: 1 }, { id: 2 }]

const UpcomingInterviewsScreen = () => {

    const renderActivityItem = () => {
        return (
            <View style={styles.container}>

                <View style={{ flexDirection: 'row' }}>
                    <Text style={[styles.smallTextStyle, { marginStart: 15, marginTop: 0, fontWeight: '500' }]}>Naveen Jaiswal</Text>
                    <Text style={[styles.smallTextStyle, { marginStart: 0, marginTop: 0 }]}> Posted this 12 hours</Text>
                </View>

                <View style={{ flexDirection: 'row', marginTop: 15 }}>
                    <View style={{ flex: 2, justifyContent: 'center', marginStart: 15 }}>
                        <View style={{ backgroundColor: '#eee', width: 50, height: 50 }} />
                    </View>
                    <View style={{ flex: 8.5 }}>
                        <Text numberOfLines={3} style={[styles.smallTextStyle, { marginTop: 0 }]}>Useful document on #productownership and #ScrumMaster</Text>

                    </View>
                </View>

                <View style={{ flexDirection: 'row', marginTop: 15, alignItems: 'center' }}>
                    <View style={{ backgroundColor: '#888', width: 18, height: 18, borderRadius: 9, marginStart: 15 }} />
                    <Text style={[styles.smallTextStyle, { marginStart: 5, fontSize: 11, marginTop: 0 }]}>15</Text>
                    <View style={{ backgroundColor: '#888', width: 18, height: 18, borderRadius: 9, marginStart: 25 }} />
                    <Text style={[styles.smallTextStyle, { marginStart: 5, fontSize: 11, marginTop: 0 }]}>77 Comments</Text>
                </View>

            </View>
        )
    }

    const renderExperienceItem = () => {
        return (
            <View style={styles.container}>

                <View style={{ flexDirection: 'row' }}>
                    <View style={{ flex: 2, marginStart: 15 }}>
                        <View style={{ backgroundColor: '#eee', width: 50, height: 50 }} />
                    </View>
                    <View style={{ flex: 8.5 }}>
                        <Text style={[styles.normalTextStyle, { fontWeight: '700' }]}>Business analyst</Text>
                        <Text numberOfLines={1} style={styles.smallTextStyle}>Nagarro . Full Time</Text>
                        <Text numberOfLines={1} style={styles.smallTextStyle}>Feb 2016 - present 6 years 7 months Typography</Text>
                        <Text numberOfLines={3} style={[styles.smallTextStyle, { marginTop: 20 }]}>Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</Text>
                    </View>
                </View>

            </View>
        )
    }

    const renderEducationItem = () => {
        return (
            <View style={styles.container}>

                <View style={{ flexDirection: 'row' }}>
                    <View style={{ flex: 2, marginStart: 15 }}>
                        <View style={{ backgroundColor: '#eee', width: 50, height: 50 }} />
                    </View>
                    <View style={{ flex: 8.5 }}>
                        <Text style={[styles.normalTextStyle, { fontWeight: '700' }]}>Indian Institute of Technology Delhi</Text>
                        <Text numberOfLines={1} style={styles.smallTextStyle}>Master Degree, Computer science</Text>
                        <Text numberOfLines={1} style={styles.smallTextStyle}>2012 - 2015</Text>
                    </View>
                </View>

            </View>
        )
    }



    return (
        <SafeAreaView style={{ flex: 1 }}>
            <ScrollView>
                <StatusBar />
                <View style={{ height: 100, backgroundColor: '#eee' }}></View>

                <View style={{ flexDirection: 'row' }}>

                    <View style={{ flex: 4, alignItems: 'center' }}>
                        <View style={{ backgroundColor: '#888', width: 80, height: 80, borderRadius: 40, marginTop: -40 }} />
                        <Text numberOfLines={1} style={[styles.smallTextStyle, { fontWeight: '600', marginTop: 14 }]}>Abstract Softweb</Text>
                        <Text numberOfLines={1} style={[styles.smallTextStyle, { marginTop: 5 }]}>Jaipur, Rajashthan</Text>
                    </View>

                    <View style={{ flex: 7 }}>
                        <Text numberOfLines={1} style={[styles.normalTextStyle, { fontSize: 17, fontWeight: '500', marginTop: 3 }]}>Naveen Jaiswal</Text>
                        <Text numberOfLines={1} style={[styles.smallTextStyle]}>Business analyst</Text>
                        <Text numberOfLines={1} style={[styles.smallTextStyle, { marginTop: 10 }]}>Rajashthan University</Text>
                        <Text numberOfLines={1} style={[styles.smallTextStyle, { marginTop: 5, color: '#0071E3', fontWeight: '600' }]}>1000+ Connections</Text>
                    </View>

                </View>

                <View style={{ backgroundColor: '#eeeeee', height: 1, marginHorizontal: 15, marginTop: 15 }} />

                <View>
                    <Text style={[styles.smallTextStyle, { marginStart: 15, marginTop: 10 }]}>3 Mutual connections : Sara david, Saurabh and 1 Other</Text>
                </View>

                <View style={{ marginHorizontal: 15, marginTop: 20, flexDirection: 'row' }}>
                    <View style={{ backgroundColor: '#000', width: 120, height: 28, borderRadius: 15, alignItems: 'center', justifyContent: 'center' }}>
                        <Text style={{ color: '#FFF' }}>Connect</Text>
                    </View>
                    <View style={{ backgroundColor: '#000', width: 120, height: 28, borderRadius: 15, alignItems: 'center', justifyContent: 'center', marginStart: 10 }}>
                        <Text style={{ color: '#FFF' }}>Message</Text>
                    </View>
                    <View style={{ borderColor: '#000', borderWidth: 1, width: 24, height: 28, borderRadius: 10, alignItems: 'center', justifyContent: 'center', marginStart: 20 }}>
                        <Text style={{ color: '#FFF' }}>Message</Text>
                    </View>
                </View>

                <View style={{ height: 10, backgroundColor: '#eee', marginTop: 20 }} />

                <View>
                    <Text style={[styles.normalTextStyle, { fontSize: 15, fontWeight: '500', marginTop: 10, marginHorizontal: 15 }]}>Activity</Text>
                    <Text style={[styles.smallTextStyle, { marginTop: 3, marginHorizontal: 15 }]}>1103 Connections</Text>

                    <FlatList
                        data={DATA}
                        renderItem={renderActivityItem}
                        ItemSeparatorComponent={() => {
                            return (
                                <View style={{ backgroundColor: '#eeeeee', height: 1, marginHorizontal: 15 }} />
                            )
                        }}
                        keyExtractor={item => item.id}
                    />
                    <View style={{ height: 1, backgroundColor: '#eee', marginHorizontal: 15 }} />

                    <View style={{ height: 40, alignItems: 'center', justifyContent: 'center', backgroundColor: '#FFF' }}>
                        <Text numberOfLines={1} style={[styles.smallTextStyle, { marginTop: 0 }]}>See all activity</Text>
                    </View>
                </View>

                <View style={{ height: 10, backgroundColor: '#eee', marginTop: 0 }} />

                <View>
                    <Text style={[styles.normalTextStyle, { fontSize: 15, fontWeight: '500', marginTop: 10, marginHorizontal: 15 }]}>About</Text>
                    <Text numberOfLines={3} style={[styles.smallTextStyle, { marginTop: 3, marginHorizontal: 15, marginBottom: 10 }]}>Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</Text>
                </View>

                <View style={{ height: 10, backgroundColor: '#eee', marginTop: 0 }} />

                <View>
                    <Text style={[styles.normalTextStyle, { fontSize: 15, fontWeight: '500', marginTop: 10, marginHorizontal: 15 }]}>Experience</Text>
                    <FlatList
                        data={DATA}
                        renderItem={renderExperienceItem}
                        ItemSeparatorComponent={() => {
                            return (
                                <View style={{ backgroundColor: '#eeeeee', height: 1, marginHorizontal: 15 }} />
                            )
                        }}
                        keyExtractor={item => item.id}
                    />
                    <View style={{ height: 1, backgroundColor: '#eee', marginHorizontal: 15 }} />

                    <View style={{ height: 40, alignItems: 'center', justifyContent: 'center', backgroundColor: '#FFF' }}>
                        <Text numberOfLines={1} style={[styles.smallTextStyle, { marginTop: 0 }]}>See all activity</Text>
                    </View>
                </View>

                <View style={{ height: 10, backgroundColor: '#eee', marginTop: 0 }} />

                <View>
                    <Text style={[styles.normalTextStyle, { fontSize: 15, fontWeight: '500', marginTop: 10, marginHorizontal: 15 }]}>Education</Text>
                    <FlatList
                        data={DATA}
                        renderItem={renderEducationItem}
                        ItemSeparatorComponent={() => {
                            return (
                                <View style={{ backgroundColor: '#eeeeee', height: 1, marginHorizontal: 15 }} />
                            )
                        }}
                        keyExtractor={item => item.id}
                    />
                    <View style={{ height: 1, backgroundColor: '#eee', marginHorizontal: 15 }} />

                    <View style={{ height: 40, alignItems: 'center', justifyContent: 'center', backgroundColor: '#FFF' }}>
                        <Text numberOfLines={1} style={[styles.smallTextStyle, { marginTop: 0 }]}>See all activity</Text>
                    </View>
                </View>

            </ScrollView>
        </SafeAreaView>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        paddingVertical: 15,
        backgroundColor: '#FFFFFF'
    },
    normalTextStyle: {
        fontSize: 15,
        color: '#000000'
    },
    smallTextStyle: {
        fontSize: 13,
        marginTop: 5,
        color: '#585C60'
    }
});

export default UpcomingInterviewsScreen;
