import React from 'react';
import Signin from "../modules/signin";

export default function () {
    return(
       <Signin/>
    );
}