import React from 'react';
import Signup from "../modules/signup";

export default function () {
    return(
       <Signup/>
    );
}