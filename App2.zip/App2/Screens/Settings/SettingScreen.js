import * as React from 'react';
import {
    SafeAreaView,
    StatusBar,
    StyleSheet,
    Text,
    View, Image, FlatList, ScrollView, useWindowDimensions
} from 'react-native';

const DATA = [{ id: 1 }, { id: 2 }, { id: 3 }, { id: 4 }, { id: 5 }]

const SettingScreen = () => {

    const renderLocationItem = () => {
        return (
            <View style={{ paddingHorizontal: 15, flexDirection: 'row' }}>

                <View style={{ flex: 1.4, justifyContent: 'center' }}>
                    <View style={{ backgroundColor: '#888', width: 24, height: 24, borderRadius: 12 }} />
                </View>
                <View style={{ flex: 9 }}>
                    <Text numberOfLines={1} style={[styles.smallTextStyle, { fontSize: 18, marginTop: 15, fontWeight: '500', color: '#000' }]}>Account preferences</Text>
                    <Text numberOfLines={20} style={[styles.smallTextStyle, { fontSize: 15, marginTop: 10, marginBottom: 20 }]}>Options for managing your account and experience on LinkedIn</Text>
                </View>
            </View>
        )
    }

    return (
        <SafeAreaView style={{ flex: 1, backgroundColor: 'white' }}>
            <StatusBar />
            <View style={{ height: 45, backgroundColor: '#000', flexDirection: 'row', alignItems: 'center' }}>
                <View style={{ backgroundColor: '#888', width: 24, height: 24, borderRadius: 12, marginStart: 15 }} />
                <Text numberOfLines={1} style={[styles.smallTextStyle, { fontSize: 16, fontWeight: '500', color: '#FFF', marginStart: 10, marginTop: 0 }]}>Settings</Text>
            </View>
            <FlatList
                data={DATA}
                renderItem={renderLocationItem}
                ItemSeparatorComponent={() => {
                    return (
                        <View style={{ backgroundColor: '#eeeeee', height: 1, marginHorizontal: 15 }} />
                    )
                }}
                keyExtractor={item => item.id}
            />
        </SafeAreaView>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        paddingVertical: 15,
        backgroundColor: '#FFFFFF'
    },
    normalTextStyle: {
        fontSize: 15,
        color: '#000000'
    },
    smallTextStyle: {
        fontSize: 13,
        marginTop: 5,
        color: '#585C60'
    }
});

export default SettingScreen;
