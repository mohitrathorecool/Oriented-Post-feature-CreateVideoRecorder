import React, {useEffect, useContext} from 'react';
import {View} from 'react-native';
import {AppContext} from '../Context';
import {isIOS, height} from '../Utils/Constant';
import CommonStyle from '../Theme/CommonStyle';
import { useNavigationFlow } from '../flows';
import { getToken } from '../Constants';

const Initial = () => {
  const {setDisplayHeight} = useContext(AppContext);
  
  const {
    goToNextScreen,
} = useNavigationFlow();
  

  useEffect(async () => {
    await getToken().then(response => 
      {console.log('response. :::: ',response)
      if(response == '')
      goToNextScreen('SignupScreen');
      else
      goToNextScreen('CreateVideoScreen');
      }
      );

    // Here we can decide the next screen
  }, []);

  const onLayout = ({nativeEvent}) => {
    setDisplayHeight((!isIOS && nativeEvent.layout.height) || height);
  };

  return <View style={CommonStyle.flexContainer} onLayout={onLayout} />;
};

export default Initial;
