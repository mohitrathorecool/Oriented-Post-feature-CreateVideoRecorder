import * as React from 'react';
import {
    SafeAreaView,
    StatusBar,
    StyleSheet,
    Text,
    View, Image, FlatList, ScrollView, useWindowDimensions
} from 'react-native';
import { TabView, SceneMap, TabBar } from 'react-native-tab-view';
import AboutScreen from './AboutScreen';

  const FirstRoute = () => (
    <View style={{ flex: 1, backgroundColor: '#ff4081' }} />
  );
  
  const SecondRoute = () => (
    <View style={{ flex: 1, backgroundColor: '#673ab7' }} />
  );

  const ThirdRoute = () => (
    <View style={{ flex: 1, backgroundColor: '#ff4081' }} />
  );
  
  const FourRoute = () => (
    <View style={{ flex: 1, backgroundColor: '#673ab7' }} />
  );
  const FiveRoute = () => (
    <View style={{ flex: 1, backgroundColor: '#ff4081' }} />
  );
  
  const SixRoute = () => (
    <View style={{ flex: 1, backgroundColor: '#673ab7' }} />
  );
  
  const renderScene = SceneMap({
    about: AboutScreen,
    post: SecondRoute,
    job: ThirdRoute,
    people: FourRoute,
    event: FiveRoute,
    //video: SixRoute,
  });
  

const CompanyProfileScreen = () => {

    const layout = useWindowDimensions();

    const [index, setIndex] = React.useState(0);
    const [routes] = React.useState([
      { key: 'about', title: 'About' },
      { key: 'post', title: 'Posts' },
      { key: 'job', title: 'Jobs' },
      { key: 'people', title: 'Peoples' },
      { key: 'event', title: 'Events' },
      //{ key: 'video', title: 'Videos' },
    ]);

    const renderLabel = ({ route, focused, color }) => (
        <Text style={{color: focused? '#0071E3' : '#888' }} >{route.title}</Text>
      );

    const renderTabBar = props => (
        <TabBar
          {...props}
          indicatorStyle={{ backgroundColor: '#0071E3' }}
          style={{ backgroundColor: 'white'}}
          activeColor={'#0071E3'}
          inactiveColor={'#888'}
          labelStyle={{fontSize: 11}}
          renderLabel={renderLabel}
        />
    );    
  


    return (
        <SafeAreaView style={{ flex: 1 }}>
            <ScrollView contentContainerStyle={{flex: 1}}>
                <StatusBar />

                <View style={{ height: 70, backgroundColor: '#eee' }}></View>

                <View style={{ flexDirection: 'column', marginStart: 15 }}>

                    <View style={{ flexDirection: 'row'}}>
                        <View style={{ backgroundColor: '#888', width: 50, height: 50, borderRadius: 25, marginTop: -25 }} />
                        <Text numberOfLines={1} style={[styles.normalTextStyle, { fontSize: 17, fontWeight: '500', marginTop: 3, marginStart: 5 }]}>Naveen Jaiswal</Text>
                    </View>

                    <View style={{ marginTop: 10  }}>
                        
                        <Text numberOfLines={1} style={[styles.smallTextStyle]}>IT Services and IT consulating</Text>
                        <View style={{flexDirection: 'row'}}>
                        <Text numberOfLines={1} style={[styles.smallTextStyle, { marginTop: 5 }]}>Jaipur, Rajasthan</Text>
                        <Text numberOfLines={1} style={[styles.smallTextStyle, { marginTop: 5, color: '#0071E3', fontWeight: '600', marginStart: 5 }]}>10,216,315 followers</Text>
                        </View>
                    </View>
                </View>


                <View style={{ marginHorizontal: 15, marginTop: 20, flexDirection: 'row' }}>
                    <View style={{ backgroundColor: '#000', width: 120, height: 28, borderRadius: 15, alignItems: 'center', justifyContent: 'center' }}>
                        <Text style={{ color: '#FFF' }}>Follow</Text>
                    </View>
                    <View style={{ backgroundColor: '#000', width: 120, height: 28, borderRadius: 15, alignItems: 'center', justifyContent: 'center', marginStart: 10 }}>
                        <Text style={{ color: '#FFF' }}>Visit Website</Text>
                    </View>
                    <View style={{ borderColor: '#000', borderWidth: 1, width: 24, height: 28, borderRadius: 10, alignItems: 'center', justifyContent: 'center', marginStart: 20 }}>
                        <Text style={{ color: '#000' }}>:</Text>
                    </View>
                </View>

                <View style={{ height: 10, backgroundColor: '#eee', marginTop: 20 }} />
                
                {/* Tab Bar */}
                <View style={{flex: 1}}>
                    <TabView
                        navigationState={{ index, routes }}
                        renderScene={renderScene}
                        onIndexChange={setIndex}
                        initialLayout={{ width: layout.width }}
                        renderTabBar={renderTabBar}
                    
                    />
                </View>


            </ScrollView>
        </SafeAreaView>


    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        paddingVertical: 15,
        backgroundColor: '#FFFFFF'
    },
    normalTextStyle: {
        fontSize: 15,
        color: '#000000'
    },
    smallTextStyle: {
        fontSize: 13,
        marginTop: 5,
        color: '#585C60'
    }
});

export default CompanyProfileScreen;
