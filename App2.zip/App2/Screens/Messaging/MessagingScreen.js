import * as React from 'react';
import {
    SafeAreaView,
    StatusBar,
    StyleSheet,
    Text,
    View, Image, FlatList, ScrollView, useWindowDimensions, TextInput
} from 'react-native';

const DATA = [{ id: 1 }, { id: 2 }, { id: 3 }, { id: 4 }, { id: 5 }]

const MessagingScreen = () => {

    const renderLocationItem = () => {
        return (
            <View style={styles.messageContainerStyle}>

                <View style={{ flex: 2, justifyContent: 'center' }}>
                    <View style={{ backgroundColor: '#888', width: 60, height: 60, borderRadius: 30 }} />
                </View>
                <View style={{ flex: 7, justifyContent: 'center' }}>
                    <View style={{ justifyContent: 'center' }}>
                        <Text numberOfLines={1} style={[styles.smallTextStyle, { fontSize: 16, marginTop: 0 }]}>Thomas Simmons</Text>
                        <Text numberOfLines={1} style={[styles.smallTextStyle, { fontSize: 15, marginTop: 5 }]}>Thank you for confirming my.</Text>
                    </View>
                </View>
                <View style={{ flex: 1, marginTop: 7, alignItems: 'center' }}>
                    <Text numberOfLines={1} style={[styles.smallTextStyle, { fontSize: 15, marginTop: 5, fontWeight: '200' }]}>Thu</Text>
                    <View style={{ backgroundColor: '#0071E3', width: 18, height: 18, borderRadius: 9, marginTop: 5, alignItems: 'center', justifyContent: 'center' }}>
                        <Text numberOfLines={1} style={[styles.smallTextStyle, { fontSize: 10, marginTop: 0, color: '#FFF', fontWeight: '500' }]}>1</Text>
                    </View>
                </View>
            </View>
        )
    }

    return (
        <SafeAreaView style={{ flex: 1, backgroundColor: 'white' }}>
            <StatusBar />
            <View style={{ height: 45, backgroundColor: '#000', flexDirection: 'row', alignItems: 'center' }}>
                <View style={{ backgroundColor: '#888', width: 24, height: 24, borderRadius: 12, marginStart: 15 }} />
                <Text numberOfLines={1} style={[styles.smallTextStyle, { fontSize: 16, fontWeight: '500', color: '#FFF', marginStart: 10, marginTop: 0 }]}>Messaging</Text>
            </View>

            <View style={styles.searchBarContainerStyle}>
            <View style={{ paddingHorizontal: 15, flexDirection: 'row', height: 50, borderRadius: 3, borderColor: '#0071E3', borderWidth: 1, marginHorizontal: 15, flex: 8.5 }}>
                <View style={{ flex: 1, justifyContent: 'center', borderEndColor: '#eee', borderEndWidth: 1 }}>
                    <View style={{ backgroundColor: '#888', width: 20, height: 20, borderRadius: 10, marginEnd: 1 }} />
                </View>
                <View style={{ flex: 8, justifyContent: 'center', paddingStart: 10}}>
                    <TextInput placeholder={'Search messages'}></TextInput>
                </View>
                <View style={{ flex: 1, alignItems: 'flex-end', justifyContent: 'center' }}>
                <View style={{ backgroundColor: '#888', width: 20, height: 20, borderRadius: 10 }} />
                </View>
            </View>

            <View style={{ flex: 1.5, justifyContent: 'center'}} >
            <View style={{ backgroundColor: '#888', width: 30, height: 30, borderRadius: 15}} />
            </View>

            </View>
            

            <View style={{paddingTop: 10, flex: 1}}>
            <FlatList
                data={DATA}
                renderItem={renderLocationItem}
                ItemSeparatorComponent={() => {
                    return (
                        <View style={{ backgroundColor: '#eeeeee', height: 1, marginHorizontal: 15 }} />
                    )
                }}
                keyExtractor={item => item.id}
            />
            </View>
        </SafeAreaView>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        paddingVertical: 15,
        backgroundColor: '#FFFFFF'
    },
    normalTextStyle: {
        fontSize: 15,
        color: '#000000'
    },
    smallTextStyle: {
        fontSize: 13,
        marginTop: 5,
        color: '#585C60'
    },
    messageContainerStyle: { paddingHorizontal: 15, flexDirection: 'row', paddingVertical: 10 },
    searchBarContainerStyle: {flexDirection: 'row', marginTop: 10}
});

export default MessagingScreen;
