import React from 'react';
import VideoRecoder from "../modules/videoRecoder";

export default function () {
    return(
       <VideoRecoder/>
    );
}