import React from "react";
import {
  FlatList,
  Image,
  ImageBackground,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import Content from "../modules/post/components/content";
import PostHeader from "../modules/post/components/PostHeader";
import * as ImagePicker from 'react-native-image-picker';
import { request, PERMISSIONS, checkMultiple } from 'react-native-permissions';
import { TouchableOpacity } from "react-native-gesture-handler";

export default function () {
  const includeExtra = true;

  const peoples = [
    { url: null },
    {
      url: {
        uri: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8cHJvZmlsZXxlbnwwfHwwfHw%3D&w=1000&q=80",
      },
    },

    {
      url: {
        uri: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8cHJvZmlsZXxlbnwwfHwwfHw%3D&w=1000&q=80",
      },
    },

    {
      url: {
        uri: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8cHJvZmlsZXxlbnwwfHwwfHw%3D&w=1000&q=80",
      },
    },

    {
      url: {
        uri: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8cHJvZmlsZXxlbnwwfHwwfHw%3D&w=1000&q=80",
      },
    },

    {
      url: {
        uri: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8cHJvZmlsZXxlbnwwfHwwfHw%3D&w=1000&q=80",
      },
    },

    {
      url: {
        uri: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8cHJvZmlsZXxlbnwwfHwwfHw%3D&w=1000&q=80",
      },
    },
    {
      url: {
        uri: "https://media.istockphoto.com/photos/headshot-portrait-of-smiling-male-employee-in-office-picture-id1309328823?b=1&k=20&m=1309328823&s=170667a&w=0&h=a-f8vR5TDFnkMY5poQXfQhDSnK1iImIfgVTVpFZi_KU=",
      },
    },
  ];


  const captureVideo = () => {
    ImagePicker.launchCamera({
      mediaType: 'video',
      videoQuality: 'medium',
      durationLimit:15,
      cameraType:'front',
      presentationStyle:'pageSheet',
      allowsEditing: true,
    }, (respionse) => {

    });
  }

  const getSavedVideo = () => {
    ImagePicker.launchImageLibrary({
      selectionLimit: 0,
      mediaType: 'video',
      includeExtra,
    }, (respionse) => {

    });
  }


  React.useEffect(() => {
    checkMultiple([PERMISSIONS.IOS.MEDIA_LIBRARY, PERMISSIONS.IOS.PHOTO_LIBRARY, PERMISSIONS.IOS.PHOTO_LIBRARY_ADD_ONLY]).then((statuses) => {

    });
  }, [])

  return (
    <SafeAreaView>
      <ScrollView>
        <View style={styles.container}>
          <View style={styles.headerContainer}>
            <Image
              style={styles.profileImage}
              source={{
                uri: "https://media-exp1.licdn.com/dms/image/C5103AQE06b99bye_mA/profile-displayphoto-shrink_200_200/0/1536221240120?e=2147483647&v=beta&t=7zoBC9NZMvC3KGjBWWAvzLgw7MzPtWk0p61C70SmEjw",
              }}
            />
            <View style={styles.nameContainer}>
              <Text style={styles.nameTxt}>Naiyra Singh</Text>
              <Text style={styles.designationtxt}>
                UI/UX designer -{" "}
                <Text style={styles.companyNameTxt}>Abstract Softweb</Text>
              </Text>
            </View>
          </View>
          <View
            style={styles.whatdoYouWantContainer}
          />
          <Text
            style={styles.whatdoYouWantTxt}
          >
            What do you want to talk about...?
          </Text>
          <View
            style={styles.postButtonContainer}
          >
            <TouchableOpacity
              style={{
                marginRight: 16,
              }}
            >
              <Image

                source={require("../Assets/Icons/Union.png")}
              />
            </TouchableOpacity>
            <Image
              style={{
                marginRight: 16,
              }}
              source={require("../Assets/Icons/Calendar.png")}
            />
            <Image source={require("../Assets/Icons/Video.png")} />
            <Text
              style={styles.postButton}
              onPress={captureVideo}
            >
              POST
            </Text>
          </View>
          <View
            style={{
              backgroundColor: "grey",
              paddingVertical: 10,
              marginTop: 5,
            }}
          >
            <FlatList
              data={peoples}
              horizontal={true}
              showsHorizontalScrollIndicator={false}
              renderItem={({ item }) => (
                <>
                  {item.url == null ? (
                    <TouchableOpacity
                      onPress={()=>{
                        alert("jj")
                      }}

                    >
                      <View
                        style={{
                          height: 53,
                          width: 53,
                          borderRadius: 100,
                          borderColor: "#0071E3",
                          backgroundColor: "#fff",
                          alignItems: "center",
                          justifyContent: "center",
                          borderWidth: 1,
                          marginLeft: 13,
                        }}
                      >


                        <Image source={require("../Assets/Icons/Video.png")} />

                      </View>
                    </TouchableOpacity>

                  ) : (
                    <Image
                      style={{
                        height: 53,
                        width: 53,
                        borderRadius: 100,
                        borderColor: "#0071E3",
                        backgroundColor: "#fff",
                        alignItems: "center",
                        justifyContent: "center",
                        borderWidth: 1,
                        marginLeft: 13,
                      }}
                      source={item.url}
                    />
                  )}
                </>
              )}
            />
          </View>

          <PostHeader />
          <Content
            video={true}
            message={`Hello, I have opening for a new career opportunity as java Developer(4), UI designer(2). i  would appreciate your support. Thanks in advance for any contact recommendation, advice, or ... see more`}
          />

          <PostHeader />
          <Content
            message={`Hello, I have opening for a new career opportunity as java Developer(4), UI designer(2). i  would appreciate your support. Thanks in advance for any contact recommendation, advice, or ... see more`}
          />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: "column",
    width: "100%",
  },
  postButtonContainer: {
    flexDirection: "row",
    justifyContent: "flex-end",
    alignItems: "center",
    marginTop: 97,
  },
  whatdoYouWantContainer: {
    width: "90%",
    height: 0.3,
    marginVertical: 12,
    marginLeft: 18,
    backgroundColor: "rgba(0, 0, 0, 0.29)",
  },
  whatdoYouWantTxt: {
    marginLeft: 18,
    color: "#979797",
    fontSize: 14,
    fontFamily: "Lato-Regular",
  },
  postButton: {
    width: 61,
    padding: 3,
    marginHorizontal: 18,
    backgroundColor: "#000000",
    color: "#fff",
    textAlign: "center",
    fontSize: 14,
  },
  headerContainer: {
    flexDirection: "row",
    marginLeft: 13,
    marginTop: 9,
  },
  profileImage: {
    width: 45,
    height: 43,
    borderRadius: 100,
  },
  nameContainer: {
    marginLeft: 8,
  },
  nameTxt: {
    fontSize: 16,
    letterSpacing: 0.1,
    fontFamily: "Lato-Regular",
    color: "#000000",
  },
  designationtxt: {
    fontSize: 12,
    lineHeight: 15,
    letterSpacing: 0.1,
    marginTop: 6,
    color: "#5F6163",
    fontFamily: "Lato-Regular",
  },
  companyNameTxt: {
    fontSize: 12,
    letterSpacing: 0.1,
    marginTop: 6,
    color: "#0071E3",
    fontFamily: "Lato-Regular",
  },
});
