import AsyncStorage from '@react-native-community/async-storage';
import {Dimensions} from 'react-native';
// Screen Route Names
export const SCREEN_SPLASH='Splash'

// Other Constants

export const KEY_BOAD_TYPE_NUMBER = 'number-pad';
export const KEY_BOAD_TYPE_DEFAULT = 'default';
export const KEY_NOFICATIONDATA = 'noficationData';
export const KEY_LABEL = 'label';
export const KEY_VALUE = 'value';
export const KEY_IS_CHECKED = 'is_checked';
export const Yellowcolour = '#cc8800';
export const Gradientcolour = '#66d9ff'
// export const Gradientcolourbluew = '#66d9ff'
// export const Gradientcolouryellow = '#ffc34d'

export const Gradientcolourbluew = '#AB326E'
export const Gradientcolouryellow = '#f7c8e0'
export const Gradientcolourlight = '#f7dae9'
export const BlueColor= '#1f497d'



export const KEY_CLICK_ACTION = 'click_action';
export const KEY_USER_DATA = 'user_data';
export const KEY_CUSTOM_NOTIFICATION = 'custom_notification';
export const NOTIFICATION_TYPE_REMINDER_DETAIL = 'reminder_detail';
export const KEY_NOTIFICATION_DATA = 'notification_data';
export const KEY_NOTIFICATION_DATA_IOS = 'gcm.notification.notification_data';
export const KEY_NOTIFICATION = 'notification';
export const KEY_PHONE = 'phone';
export const KEY_DEVICE_TYPE = 'device_type';
export const KEY_DEVICE_ID = 'device_id';
export const KEY_DEVICE_TOKEN = 'device_token';
export const OS_TYPE_ANDROID = 'android';
export const OS_TYPE_IOS = 'ios';
export const LIST_THRESHOLD = 0.5;




export const METHOD_TYPE_POST = 'POST';
export const METHOD_TYPE_GET = 'get';
export const METHOD_TYPE_DELETE = 'delete';
export const METHOD_TYPE_PUT = 'PUT';
const AuthToken = 'AuthToken'
/////////////////////////////////////// API NAMES ////////////////////////////////////

export const BASE_URL = 'http://63.142.251.228:8080/api/';

export const getToken = async () => {
    const jsonValue = await AsyncStorage.getItem(AuthToken);
    return jsonValue != null ? jsonValue : '';
  };
  

  export const setToken = async (token: string, expires_in: number) => {
    await AsyncStorage.setItem(AuthToken, token);
  };


export const API_GET_BUSINESS_REWARD = BASE_URL+'getbusiness_points';


export const getFormatedDateForServer = (date) =>{
    const newdate =date.split("/")
    return `${newdate[2]}/${newdate[1]}/${newdate[0]}`
}
