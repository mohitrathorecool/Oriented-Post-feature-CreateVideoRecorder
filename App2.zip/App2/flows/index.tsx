import {useNavigation, CommonActions} from '@react-navigation/native';

export const useNavigationFlow = () => {

    const navigation = useNavigation();

    const goToNextScreen = async (name, params = {}) => {
        navigation.dispatch(
          CommonActions.reset({
            index: 0,
            routes: [{name, params}],
          }),
        );
    };

    const navigateToHome = (params = {}) => {
        // navigation.navigate('Home', params);
        navigation.navigate('HalfScreenVideoRecorder', params);
    }; 

    const navigateToSignIn = (params = {}) => {
        navigation.navigate('SigninScreen', params);
    };  

    const navigateToOTP = (params = {}) => {
        navigation.navigate('OTPScreen', params);
    };

    const navigateToSignUp = (params = {}) => {
        navigation.navigate('SignupScreen', params);
    };

    const navigateToCreateVideo = (params = {}) => {
        navigation.navigate('CreateVideoScreen', params);
    };

    return {goToNextScreen,
        navigateToHome,
        navigateToSignIn,
        navigateToOTP,
        navigateToSignUp,
        navigateToCreateVideo};  

}