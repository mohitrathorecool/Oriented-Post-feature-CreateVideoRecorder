export const data = [
  {
    id: 1,
    post: {
      url: require('../Assets/video1.mov'),
    },
    user: {
      userId: 1,
      name: 'Kalki Patel',
      isFollowing: false,
    },
    comment: 101,
    like: '121.3 k',
    likeStatus: true,
    postText: 'React Native reels with actions shown in this project',
  },
  {
    id: 2,
    post: {
      url: require('../Assets/video2.mov'),
    },
    user: {
      userId: 2,
      name: 'Kajol Patel',
      isFollowing: true,
    },
    comment: 100,
    like: '10.3 k',
    likeStatus: false,
    postText: 'React Native reels with actions shown in this project',
  },
  {
    id: 3,
    post: {
      url: require('../Assets/video3.mov'),
    },
    user: {
      userId: 3,
      name: 'Kalki Patel',
      isFollowing: false,
    },
    comment: 10,
    like: '121',
    likeStatus: true,
    postText: 'React Native reels with actions shown in this project',
  },
  {
    id: 4,
    post: {
      url: require('../Assets/video4.mov'),
    },
    user: {
      userId: 4,
      name: 'Kajol Patel',
      isFollowing: true,
    },
    comment: 300,
    like: '150.3 k',
    likeStatus: false,
    postText: 'React Native reels with actions shown in this project',
  },
  {
    id: 5,
    post: {
      url: require('../Assets/video5.mov'),
    },
    user: {
      userId: 5,
      name: 'Kalki Patel',
      isFollowing: false,
    },
    comment: 320,
    like: '121.3 k',
    likeStatus: true,
    postText: 'React Native reels with actions shown in this project',
  },
];
