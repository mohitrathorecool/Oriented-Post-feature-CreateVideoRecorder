import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import Initial from '../Screens/Initial';
import Home from '../Screens/Home';
import SignupScreen from '../Screens/SignupScreen';
import SigninScreen from '../Screens/SigninScreen';
import OTPScreen from '../Screens/OTPScreen';
import CreateVideoScreen from '../Screens/CreateVideoScreen';
import HalfScreenVideoRecorder from '../Screens/HalfScreenVideoRecorder';

const Stack = createStackNavigator();

const AppNavigation = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen
          name={'Inital'}
          component={Initial}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name={'Home'}
          component={Home}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name={'SignupScreen'}
          component={SignupScreen}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name={'SigninScreen'}
          component={SigninScreen}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name={'OTPScreen'}
          component={OTPScreen}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name={'CreateVideoScreen'}
          component={CreateVideoScreen}
          options={{ headerShown: false }}
        />

        <Stack.Screen
          name={'HalfScreenVideoRecorder'}
          component={HalfScreenVideoRecorder}
          options={{ headerShown: false }}
        />


      </Stack.Navigator>
    </NavigationContainer>
  );
};

export default AppNavigation;
