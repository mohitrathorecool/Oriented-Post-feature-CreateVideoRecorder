import React from "react";
import {
  Image,
  ImageBackground,
  StyleSheet,
  Text,
  View,
} from "react-native";

export default function ({ message, video }) {
  return (
    <View>
      <Text style={styles.message}>{message}</Text>
      {video && (
        <ImageBackground style={styles.videoContainer}>
          <Image
            resizeMode="cover"
            style={styles.videoThumnil}
            source={{
              uri: "https://thumbs.dreamstime.com/b/creative-conversion-woman-holding-shard-broken-mirror-creative-conversion-woman-holding-shard-broken-mirror-107163018.jpg",
            }}
          />

          <Image
            style={styles.bigPlay}
            source={require("../../../../Assets/Icons/Play.png")}
          />

          <View style={styles.videoInfoContainer}>
            <Image
              style={styles.smallPlay}
              source={require("../../../../Assets/Icons/Play.png")}
            />

            <Text style={styles.duration}>5:00</Text>
          </View>
        </ImageBackground>
      )}
      <View style={styles.instantLikeContainer}>
        <View style={styles.likeCommentShareContainer}>
          <Image source={require("../../../../Assets/Icons/small_like.png")} />
          <Text
            style={{
              marginLeft: 4,
            }}
          >
            77
          </Text>
        </View>

        <Text>11 Comments</Text>
      </View>
      <View style={styles.saperator} />

      <View style={styles.likeCommentShareContainer}>
        <View style={styles.likeContainer}>
          <Image source={require("../../../../Assets/Icons/like_post.png")} />
          <Text style={styles.likeTxt}>Like</Text>
        </View>
        <View style={styles.commentContainer}>
          <Image source={require("../../../../Assets/Icons/coment_post.png")} />
          <Text style={styles.commentTxt}>Comments</Text>
        </View>
        <View style={styles.shareContainer}>
          <Image source={require("../../../../Assets/Icons/share_post.png")} />
          <Text style={styles.shareTxt}>Share</Text>
        </View>
      </View>
      <View style={styles.bottomSpace} />
    </View>
  );
}

const styles = StyleSheet.create({
  bottomSpace: {
    height: 20,
    width: "100%",
    backgroundColor: "#F5F5F7",
    marginTop: 10,
  },
  message: {
    paddingHorizontal: 23,
    marginTop: 2,
    fontFamily: "Lato-Regular",
    fontSize: 14,
    color: "#000",
  },
  videoContainer: {
    width: "100%",
    height: 227,
    alignSelf: "center",
    alignItems: "center",
    marginTop: 8,
    paddingHorizontal: 23,
  },
  videoInfoContainer: {
    width: "100%",
    height: 22,
    position: "absolute",
    bottom: 0,
    flexDirection: "row",
    justifyContent: "space-between",

    backgroundColor: "rgba(0, 0, 0, 0.66)",
  },
  duration: {
    color: "#fff",
    marginRight: 17,
    marginTop: 2,
  },
  shareContainer: {
    alignItems: "center",
    marginLeft: 57,
  },
  shareTxt: {
    marginTop: 9,
  },
  commentContainer: {
    alignItems: "center",
    marginLeft: 64,
  },
  commentTxt: {
    marginTop: 9,
  },
  likeContainer: {
    alignItems: "center",
    marginLeft: 23,
  },
  likeTxt: {
    marginTop: 9,
  },
  likeCommentShareContainer: {
    flexDirection: "row",
    alignItems: "center",
  },
  videoThumnil: {
    width: "100%",
    height: "100%",
  },
  saperator: {
    width: "90%",
    height: 0.3,
    marginVertical: 12,
    marginLeft: 18,

    backgroundColor: "rgba(0, 0, 0, 0.29)",
  },
  instantLikeContainer: {
    justifyContent: "space-between",
    flexDirection: "row",
    marginHorizontal: 23,
    marginTop: 8,
  },
  smallPlay: {
    width: 18,
    height: 18,
    marginTop: 2,
    marginLeft: 20,
  },
  bigPlay: {
    position: "absolute",
    bottom: 110,
    alignSelf: "center",
  },
});