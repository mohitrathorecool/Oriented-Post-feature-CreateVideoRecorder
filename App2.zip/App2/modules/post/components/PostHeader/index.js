import React from "react";
import {
  FlatList,
  Image,
  ImageBackground,
  SafeAreaView,
  StyleSheet,
  Text,
  View,
} from "react-native";

export default function () {
  return (
    <View style={styles.container}>
      <Image
        style={styles.profileImage}
        source={{
          uri: "https://media-exp1.licdn.com/dms/image/C5103AQE06b99bye_mA/profile-displayphoto-shrink_200_200/0/1536221240120?e=2147483647&v=beta&t=7zoBC9NZMvC3KGjBWWAvzLgw7MzPtWk0p61C70SmEjw",
        }}
      />
      <View style={styles.nameContainer}>
        <Text style={styles.nameTxt}>Naiyra Singh</Text>
        <Text style={styles.designationTxt}>
          UI/UX designer -{" "}
          <Text style={styles.companyTxt}>Abstract Softweb</Text>
        </Text>
        <Text
          style={styles.agoTxt}
        >
          1h Ago
        </Text>
      </View>
      <Image
        style={styles.moreImage}
        source={require("../../../../Assets/Icons/dots.png")}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    marginLeft: 13,
    marginTop: 9,
  },
  profileImage: {
    width: 45,
    height: 43,
    borderRadius: 100,
  },
  nameContainer: {
    marginLeft: 8,
  },
  nameTxt: {
    fontSize: 18,
    letterSpacing: 0.1,
    color: "#000000",
    fontFamily: "Lato-Regular",
  },
  designationTxt: {
    fontSize: 14,
    letterSpacing: 0.1,
    marginTop: 6,
    color: "#5F6163",
    fontFamily: "Lato-Regular",
  },
  companyTxt: {
    fontSize: 12,
    letterSpacing: 0.1,
    marginTop: 6,
    color: "#0071E3",
    fontFamily: "Lato-Regular",
  },
  agoTxt : {
    fontSize: 12,
    letterSpacing: -0.5,
    marginTop: 5,
    fontFamily: "Lato-Regular",
    color: "#5F6163",
  },
  moreImage : {
    marginTop: 10,
    position: "absolute",
    right: 30,
  }
});

