export const SIGNUP = 'Signup :';
export const ENTER_NAME = 'Enter name';
export const EMAIL_ADDRESS = 'Email address';
export const PASSWORD = 'Password';
export const ENTER_MOBILE_NUMBER = 'Enter Mobile Number'
export const CREATE = 'Create';
export const ALREADY_HAVE_ACCOUNT = 'Already have account  ';
export const LOGIN = 'Login'
