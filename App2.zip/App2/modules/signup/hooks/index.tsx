import { useTheme } from 'react-native-elements';
import { useNavigationFlow } from '../../../flows';
import { addTheme } from "../styles";

export const useSignUp = () => {

    const { theme } = useTheme();
    const themeStyles = addTheme(theme);

    const {
        navigateToSignIn,
        navigateToOTP,
    } = useNavigationFlow();

    const onPressLogin = () => {
        navigateToSignIn();
    };

    const onCreate = () => {
        navigateToOTP();
    };

    return {themeStyles,
        onPressLogin,
        onCreate};
}