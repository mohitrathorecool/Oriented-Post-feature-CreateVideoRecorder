import {StyleSheet} from 'react-native';
import { Colors } from '../../Theme/Colors';

export const addTheme = (theme: any) => {
    return StyleSheet.create({
        container: {
          flexDirection: "column",
          flex:1        
        },

        signUpViewBackground: {
            resizeMode: 'contain',
            width: '100%',
            flex:7,
            backgroundColor:'black'
        },

        signupBottomView: {
            flex:4,
            width: '100%',
            backgroundColor: Colors.white,
            alignItems: 'center',
            position: 'absolute',
            bottom: 0,
            borderRadius: 18,
            shadowColor: Colors.shadowGray,
            shadowOpacity: 0.7,
            shadowRadius: 9,
            shadowOffset: {
                height: 4,
                width: 0
            },
            paddingVertical: 15,
        },
        signUpView: {
            width: '100%',
            paddingTop : 24,
            paddingBottom: 14,
            paddingStart: 14,
            paddingEnd: 14,
        },
        signUpText: {
            fontWeight: 'normal',
            fontSize: 18,
            color: Colors.black,
        },

        nameSection: {
            flex: 1,
            flexDirection: 'row',
            justifyContent: 'center',
            alignItems: 'center',
            marginTop: 23,
        },

        nameInputFiled: {
            width: '100%',
            height: 50,
            borderWidth:1,
            borderColor: Colors.borderColor,
            borderRadius: 4,
            paddingLeft: 15,
            fontSize: 15,
        },

        emailAddressInputFiled: {
            width: '100%',
            height: 50,
            marginTop: 14,
            borderWidth:1,
            borderColor: Colors.borderColor,
            borderRadius: 4,
            paddingLeft: 15,
            fontSize: 15,
        },

        passwordInputFiled: {
            width: '100%',
            height: 50,
            marginTop: 14,
            borderWidth:1,
            borderColor: Colors.borderColor,
            borderRadius: 4,
            paddingLeft: 15,
            fontSize: 15,
        },

        phoneNumberContainer: {
            flexDirection: "row",
            flex:1,
            marginTop: 14,
        },

        phoneNumberInputFiled: {
            flex:1,
            height: 50,
            borderWidth:1,
            borderColor: Colors.borderColor,
            borderBottomLeftRadius: 0,
            borderBottomRightRadius: 4,
            borderTopLeftRadius: 0,
            borderTopRightRadius: 4,
            paddingLeft: 15,
            fontSize: 15,
            borderLeftColor: Colors.white,
        },

        buttonView: {
            flexDirection: "row",
            justifyContent: "flex-end"
        },

        buttonStart: {
            width: 112,
            height: 40,
            marginTop: 22,
            backgroundColor: Colors.black,
            borderRadius: 4,
            justifyContent: 'center',
            alignItems: 'center',
        },

        buttonText: {
            fontSize: 18,
            color: Colors.white
        },

         loginView: {
            marginTop: 52,
            marginBottom: 13,
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
        },

        accountText: {
            fontSize: 20,
            justifyContent: 'center',
            alignItems: 'center',
        },

        loginText: {
            fontSize: 20,
            justifyContent: 'center',
            alignItems: 'center',
            color: Colors.blueTextColor,
        },
    });
}