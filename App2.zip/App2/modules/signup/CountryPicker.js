import React, { Component } from 'react';
import { StyleSheet, View, TouchableOpacity, Text } from 'react-native';
import { Colors } from '../../Theme/Colors';
import PhoneInput from 'react-native-phone-input';

class CustomCountryPicker extends Component {
    constructor() {
        super();
    
    }
    updateInfo() {
        this.setState({
          valid: this.phone.isValidNumber(),
          type: this.phone.getNumberType(),
          value: this.phone.getValue()
        });
    }
    
      render() {
        return (
          <View style={styles.container}>
            <PhoneInput
              ref={ref => {
                this.phone = ref;
              }}
              initialCountry = 'in'
            />
          </View>
        );
      }
    }
    
    let styles = StyleSheet.create({
      container: {
        alignItems: "center",
        padding: 13,
        borderWidth:1,
        borderColor: Colors.borderColor,
        borderBottomLeftRadius: 4,
        borderBottomRightRadius: 0,
        borderTopLeftRadius: 4,
        borderTopRightRadius: 0,
        width:100,
        height: 50,
      },
    });

export default CustomCountryPicker;