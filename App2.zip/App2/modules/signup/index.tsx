import React from 'react';
import { TouchableOpacity } from 'react-native';
import { View, Text, Image, ImageBackground } from 'react-native';
import { TextInput } from 'react-native-gesture-handler';
import { EntryExitTransition } from 'react-native-reanimated';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Icon } from 'react-native-vector-icons/Icon';
import { AppImages } from '../../Theme/AppImages';
import { ALREADY_HAVE_ACCOUNT, CREATE, EMAIL_ADDRESS, ENTER_MOBILE_NUMBER, ENTER_NAME, LOGIN, PASSWORD, SIGNUP } from './constants';
import CustomCountryPicker from './CountryPicker';
import { useSignUp } from './hooks';

export default function (props:any) {
    const {
        themeStyles,
        onPressLogin,
        onCreate,
    } = useSignUp(props);
    
    return (
        <SafeAreaView style={themeStyles.container}>
            {/* <Image 
                   style={themeStyles.signUpViewBackground}
            ></ */}
          
            <ImageBackground style={{flex: 1,
                width: '100%',
                flex:0.56,
                resizeMode: 'stretch'}} 
                source={(AppImages.signupBackground)} />
           
            <View style={themeStyles.signupBottomView}>
                <View style={themeStyles.signUpView}>
                    <Text style={themeStyles.signUpText}> {SIGNUP}</Text>
                    <View style={themeStyles.nameSection}>
                    {/* <Icon size={24} color="white" name="user" /> */}
                        <TextInput style={themeStyles.nameInputFiled}
                            placeholder={ENTER_NAME}/>
                    </View>
                    <TextInput style={themeStyles.emailAddressInputFiled}
                        placeholder={EMAIL_ADDRESS}/>
                    <TextInput style={themeStyles.passwordInputFiled}
                        secureTextEntry={true}
                        placeholder={PASSWORD}/>
                    <View style={themeStyles.phoneNumberContainer}>
                        <CustomCountryPicker
                        />
                        <TextInput style={themeStyles.phoneNumberInputFiled}
                            placeholder={ENTER_MOBILE_NUMBER}
                            keyboardType="numeric"/>
                    </View>
                    <View style = {themeStyles.buttonView}>
                        <TouchableOpacity style = {themeStyles.buttonStart}
                        onPress={onCreate}>
                            <Text style = {themeStyles.buttonText}>
                                {CREATE}
                            </Text>
                        </TouchableOpacity>
                    </View>
                    <View style = {themeStyles.loginView}>
                        <Text style = {themeStyles.accountText}>
                            {ALREADY_HAVE_ACCOUNT}
                        </Text>
                        <Text style = {themeStyles.loginText}
                                onPress={onPressLogin}>
                            {LOGIN}
                        </Text>
                    </View>
                </View> 
            </View>
        </SafeAreaView>
    );
}