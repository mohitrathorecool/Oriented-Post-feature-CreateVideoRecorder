import React from "react";
import { View } from "react-native";
import { ImageBackground, SafeAreaView, Text,TextInput, TouchableOpacity } from "react-native";
import { AppImages } from "../../Theme/AppImages";
import { CREATE, IN_SECONDS, ONE_TIME_PASSWORD, OTP, RESEND } from "./constants";
import { useOTP } from "./hooks";

export default function (props:any) {

    const {
        themeStyles,
        onPressCreate,
        onPresResend,
    } = useOTP(props);

    return(
        <SafeAreaView style={themeStyles.container}>
            <ImageBackground style={{flex: 1,
            width: '100%',
            flex:0.56,
            resizeMode: 'stretch'}} 
            source={(AppImages.otpBackground)} />

            <View style={themeStyles.otpBottomView}>
                <View style={themeStyles.otpView}>
                    <Text style={themeStyles.otpText}> {OTP}</Text>
                    <Text style={themeStyles.passwordNumberText}> {ONE_TIME_PASSWORD}</Text>
                    <Text style={themeStyles.passwordNumberText}> {'+91 *******440'}</Text>
                    <View style={themeStyles.otpNumberView}>
                        <View style={themeStyles.otpNumberFiledView}>
                            <TextInput style={themeStyles.otpNumberText}
                                maxLength={1}></TextInput>
                        </View>
                        <View style={themeStyles.otpNumberFiledView}>
                            <TextInput style={themeStyles.otpNumberText}
                                maxLength={1}></TextInput>
                        </View>
                        <View style={themeStyles.otpNumberFiledView}>
                            <TextInput style={themeStyles.otpNumberText}
                                maxLength={1}></TextInput>
                        </View>
                        <View style={themeStyles.otpNumberFiledView}>
                            <TextInput style={themeStyles.otpNumberText}
                                maxLength={1}></TextInput>
                        </View>
                    </View>
                    <View style = {themeStyles.bottomView}>
                        <View style = {themeStyles.resendView}>
                            <Text style={themeStyles.resendText}
                                onPress={onPresResend}> {RESEND}</Text>
                            <Text style={themeStyles.secondsText}> {IN_SECONDS}</Text>
                        </View>
                        <View style = {themeStyles.buttonView}>
                            <TouchableOpacity style = {themeStyles.buttonStart}
                                onPress={onPressCreate}>
                                <Text style = {themeStyles.buttonText}>
                                    {CREATE}
                                </Text>
                            </TouchableOpacity>
                        </View>
                    </View>
                </View>
            </View>
    
        </SafeAreaView>
    );

}