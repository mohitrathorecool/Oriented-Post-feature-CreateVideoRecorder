export const OTP = 'OTP';
export const ONE_TIME_PASSWORD = 'One time password has been sent to :'
export const RESEND = 'Resend';
export const IN_SECONDS = 'in 60 seconds...';
export const CREATE = 'Create';
