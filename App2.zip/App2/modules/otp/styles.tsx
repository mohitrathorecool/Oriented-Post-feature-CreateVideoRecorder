import {StyleSheet} from 'react-native';
import { Colors } from '../../Theme/Colors';

export const addTheme = (theme: any) => {
    return StyleSheet.create({
        container: {
          flexDirection: "column",
          flex:1        
        },

        otpBottomView: {
            flex:4,
            width: '100%',
            backgroundColor: Colors.white,
            alignItems: 'center',
            position: 'absolute',
            bottom: 0,
            borderRadius: 18,
            shadowColor: Colors.shadowGray,
            shadowOpacity: 0.7,
            shadowRadius: 9,
            shadowOffset: {
                height: 4,
                width: 0
            },
            paddingVertical: 15,
        },

        otpView: {
            width: '100%',
            paddingTop : 24,
            paddingBottom: 14,
            paddingStart: 14,
            paddingEnd: 14,
        },

        otpText: {
            fontWeight: 'normal',
            fontSize: 18,
            color: Colors.black,
        },

        passwordNumberText: {
            fontWeight: 'normal',
            fontSize: 18,
            color: Colors.black,
            marginTop: 9,
        },

        otpNumberView: {
            flex: 1,
            marginTop: 18,
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
        },

        otpNumberFiledView: {
            flex: 1,
            justifyContent: "center",
            alignItems: "center",
        },

        otpNumberText: {
            width: 68,
            height: 50,
            fontWeight: 'normal',
            fontSize: 22,
            color: Colors.black,
            borderWidth:1,
            borderColor: Colors.lightGrayButtonColor,
            borderRadius: 4,
            textAlign: "center",
            textAlignVertical: "center",
        },

        bottomView: {
            width: '100%',
            flex: 1,
            marginTop: 52,
            marginBottom: 30,
            flexDirection: "row",
        },

        resendView: {
            flexDirection: "row",
            justifyContent: "flex-start",
            alignItems: 'center',
        },

        resendText: {
            fontWeight: 'normal',
            fontSize: 18,
            color: Colors.blueTextColor,
        },

        secondsText: {
            fontWeight: 'normal',
            fontSize: 18,
            color: Colors.lightGrayTextColor,
        },

        buttonView: {
            flex: 1,
            flexDirection: "row",
            justifyContent: "flex-end",
        },

        buttonStart: {
            width: 112,
            height: 40,
            backgroundColor: Colors.black,
            borderRadius: 4,
            justifyContent: 'center',
            alignItems: 'center',
        },

        buttonText: {
            fontWeight: 'normal',
            fontSize: 18,
            color: Colors.white
        },
    });
}