import { useTheme } from 'react-native-elements';
import { useNavigationFlow } from '../../../flows';
import { addTheme } from "../styles";
import React, { useEffect } from 'react';
import { checkMultiple, PERMISSIONS, requestMultiple } from 'react-native-permissions';
import {launchCamera, launchImageLibrary} from 'react-native-image-picker';
import { Alert } from 'react-native';

export const useOTP = () => {

    const { theme } = useTheme();
    const themeStyles = addTheme(theme);

    const {
        navigateToHome,
    } = useNavigationFlow();

    const onPressCreate = () => {
        navigateToHome();
    };

    React.useEffect(()=>{
        requestMultiple([PERMISSIONS.ANDROID.CAMERA,PERMISSIONS.ANDROID.RECORD_AUDIO,PERMISSIONS.IOS.MEDIA_LIBRARY, PERMISSIONS.IOS.PHOTO_LIBRARY,PERMISSIONS.IOS.PHOTO_LIBRARY_ADD_ONLY]).then((kk)=>{

        })

    },[])

    const onPresResend = async () => {
        const result = await launchCamera({
            mediaType: 'video',
            includeExtra: true,
        });
debugger;
console.log(result);

    };

    return {themeStyles,
        onPressCreate,
        onPresResend,
    };
}