import React from 'react';
import { useTheme } from 'react-native-elements';
import { checkMultiple, PERMISSIONS } from 'react-native-permissions';
import { addTheme } from "../styles";

export const useCreateVideo = () => {

    const { theme } = useTheme();
    const themeStyles = addTheme(theme);

    React.useEffect(() => {
        checkMultiple([PERMISSIONS.ANDROID.CAMERA, PERMISSIONS.ANDROID.RECORD_AUDIO, PERMISSIONS.IOS.MEDIA_LIBRARY, PERMISSIONS.IOS.PHOTO_LIBRARY, PERMISSIONS.IOS.PHOTO_LIBRARY_ADD_ONLY]).then((_statuses) => {
            
        });

    }, [])
    return { themeStyles };
}