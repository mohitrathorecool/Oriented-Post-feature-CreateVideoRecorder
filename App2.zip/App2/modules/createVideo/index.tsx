import React, { useEffect, useState } from "react";
import { View, Text, Dimensions, TouchableOpacity } from 'react-native';
import { SafeAreaView } from "react-native-safe-area-context";
import { DESIER_SKILLS, SELECT_SKILLS, SELECT_THE_TIME_RECORD, WRITE_SOMETHING, START } from "./constants";
import TagInput from 'react-native-tags-input';
import { addTheme } from "./styles";
import { Colors } from '../../Theme/Colors';
import { TextInput } from "react-native-gesture-handler";
import { Menu, MenuItem, MenuDivider } from 'react-native-material-menu';
import { Button } from "react-native-elements/dist/buttons/Button";

import * as ImagePicker from 'react-native-image-picker';
import {request, PERMISSIONS, checkMultiple} from 'react-native-permissions';

/* toggle includeExtra */
const includeExtra = true;
const mainColor = '#3ca897';


export default class CreateVideo extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
          tags: {
            tag: '',
            tagsArray: ['Full stack developer',
                        'Scrum Master','Microsoft Power BI','Product Owner']
          },
          tagsColor: mainColor,
          tagsText: '#fff',
          isShowMenu: false,
        };
      }
        
      updateTagState = (state) => {
          this.setState({
            tags: state
          })
        };
        

    render() {
        const themeStyles = addTheme(null);

        const hideMenu = () => {
            this.setState({ isShowMenu: false })
        };

        const showMenu = () => {
            this.setState({ isShowMenu: true })
        };
    
        return(
            <SafeAreaView style={themeStyles.container}>
                <View style={themeStyles.selectSkillsView}>
                    <TagInput
                            updateState={this.updateTagState}
                            tags={this.state.tags}
                            placeholder={SELECT_SKILLS}                           
                            inputContainerStyle={themeStyles.selectSkillsInputFiled}
                            inputStyle={{color: Colors.borderColor}}
                            customElement={<Text style={themeStyles.desierSkillsText}> {DESIER_SKILLS}</Text>}
                            onFocus={() => this.setState({tagsColor: Colors.borderColor, tagsText: Colors.white})}
                            onBlur={() => this.setState({tagsColor: Colors.borderColor, tagsText: Colors.white})}
                            autoCorrect={false}
                            tagStyle={themeStyles.tag}
                            tagTextStyle={themeStyles.tagText}
                            keysForTag={', '}/>
                </View>
                <View style={themeStyles.writeSometingView}>
                    <TextInput style={themeStyles.writeSomethingInputFiled}
                        placeholder={WRITE_SOMETHING}
                        multiline={true}>
                    </TextInput>
                </View>
                <View style={themeStyles.timeRecordContainerView}>
                    <View style={themeStyles.timeRecordView}>
                        <View style={themeStyles.timeRecordTextView}>
                            <Menu
                                visible={this.state.isShowMenu}
                                anchor={<Text onPress={showMenu}>{SELECT_THE_TIME_RECORD}</Text>}
                                onRequestClose={hideMenu}>
                                <MenuItem onPress={hideMenu}>30 Seconds</MenuItem>
                                <MenuItem onPress={hideMenu}>1 Hour</MenuItem>
                            </Menu>
                        </View>
                    </View>
                    <View style = {themeStyles.buttonView}>
                        <TouchableOpacity onPress={()=>{
                            
                                                }} style = {themeStyles.buttonStart}>
                            <Text style = {themeStyles.buttonText}>
                                {START}
                            </Text>
                        </TouchableOpacity>
                    </View>
                </View>
            </SafeAreaView>
        );
    }
}