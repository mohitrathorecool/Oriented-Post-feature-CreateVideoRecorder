export const SELECT_SKILLS = 'Select Skills'; 
export const DESIER_SKILLS = 'Desier skills :';
export const WRITE_SOMETHING = 'Write SOMETHING #Include';
export const SELECT_THE_TIME_RECORD = 'Select the time record';
export const START = 'Start';