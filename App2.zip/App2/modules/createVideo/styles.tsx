import {StyleSheet} from 'react-native';
import { colors } from 'react-native-elements';
import { Colors } from '../../Theme/Colors';

export const addTheme = (theme: any) => {
    return StyleSheet.create({
        container: {
            flex: 1,
        },

        selectSkillsView: {
            backgroundColor: Colors.white,
            width: '100%',
            paddingTop: 23,
            paddingBottom: 16,
        },

        createVideoView: {
            width: '100%',
            paddingBottom: 14,
            paddingStart: 14,
            paddingEnd: 14,
        },

        selectSkillsInputFiled: {
            width: '100%',
            height: 43,
            borderWidth:1,
            borderColor: Colors.borderColor,
            borderRadius: 4,
            paddingLeft: 15,
            fontSize: 15,
        },

        desierSkillsText: {
            marginTop: 8,
            fontWeight: 'normal',
            fontSize: 12,
            color: Colors.grayTextColor,
        },

        tag: {
            backgroundColor: '#fff',
            borderColor: Colors.grayTextColor,
        },
        tagText: {
            color: Colors.grayTextColor,
        },

        writeSometingView: {
            backgroundColor: Colors.white,
            width: '100%',
            paddingTop: 13,
            paddingBottom: 20,
            paddingStart: 14,
            paddingRight: 14,
            marginTop: 9,
        },

        writeSomethingInputFiled: {
            width: '100%',
            height: 78,
            borderWidth:1,
            borderColor: Colors.borderColor,
            borderRadius: 4,
            paddingLeft: 15,
            fontSize: 15,
            textAlignVertical: 'top',
        },

        timeRecordContainerView: {
            backgroundColor: Colors.white,
            width: '100%',
            paddingTop: 13,
            paddingBottom: 20,
            paddingStart: 14,
            paddingRight: 14,
            marginTop: 9,
        },

        timeRecordView: {
            backgroundColor: Colors.white,
            width: '100%',
            justifyContent: 'center',
            alignItems: 'center',
        },

        timeRecordTextView: {
            width: '100%',
            height: 50,
            borderColor: Colors.borderColor,
            borderWidth:1,
            textAlign: 'center',
            justifyContent: 'center',
            alignItems: 'center',
            alignSelf:'center',
            textAlignVertical: 'center',
            alignContent: 'center',
        },

        buttonView: {
            flexDirection: "row",
            justifyContent: "flex-end"
        },

        buttonStart: {
            width: 112,
            height: 40,
            marginTop: 31,
            backgroundColor: Colors.black,
            borderRadius: 4,
            justifyContent: 'center',
            alignItems: 'center',
         },

         buttonText: {
            fontSize: 18,
            color: Colors.white
         }


    });
}