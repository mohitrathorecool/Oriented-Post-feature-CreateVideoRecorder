import { useTheme } from 'react-native-elements';
import { useNavigationFlow } from '../../../flows';
import { addTheme } from "../styles";
import { BASE_URL, setToken } from "../../../Constants";
import { useState } from 'react';
export const useSignIn = () => {

    const { theme } = useTheme();
    const themeStyles = addTheme(theme);
    const [mobile, setMobile] = useState('');
    const [password, setPassword] = useState('');

    async function cllapiforgonlotp() {
        var data = new URLSearchParams();
        data.append('mobile', mobile);
        data.append('password', password)

        debugger;

        fetch(BASE_URL+'users/user-login', {
          method: "POST",
          headers: {
            'Accept': "application/json",
            'Content-Type': 'application/x-www-form-urlencoded'
          },
          body: data.toString(),
          json: true,
        })
          .then(response => response.json())
          .then(responseJson => {
            console.warn(JSON.stringify(responseJson))
            setToken(responseJson.token,1000)
    
          })
          .catch(error => {
            setTimeout(() => {
              alert(error);
            }, 300);
          });
      }
    const {
        navigateToSignUp,
        navigateToOTP,
    } = useNavigationFlow();

    const onPressCreateAccount = () => {
        navigateToSignUp();
    };

    const onCreate = () => {
         cllapiforgonlotp()
       // navigateToOTP();
    };

    const onPressForgetPassword = () => {
        
    };

    const onPressGoogle = () => {
        
    };

    return {themeStyles,
        onPressCreateAccount,
        onCreate,
        mobile,
        setMobile,
        password,
        setPassword,
        onPressForgetPassword,
        onPressGoogle};
}
