import {StyleSheet} from 'react-native';
import { Colors } from '../../Theme/Colors';

export const addTheme = (theme: any) => {
    return StyleSheet.create({
        container: {
          flexDirection: "column",
          flex:1        
        },

        signInViewBackground: {
            resizeMode: 'contain',
            width: '100%',
            flex:7,
            backgroundColor:'black'
        },

        signInBottomView: {
            flex:4,
            width: '100%',
            backgroundColor: Colors.white,
            alignItems: 'center',
            position: 'absolute',
            bottom: 0,
            borderRadius: 18,
            shadowColor: Colors.shadowGray,
            shadowOpacity: 0.7,
            shadowRadius: 9,
            shadowOffset: {
                height: 4,
                width: 0
            },
            paddingVertical: 15,
        },

        signInView: {
            width: '100%',
            paddingTop : 24,
            paddingBottom: 14,
            paddingStart: 14,
            paddingEnd: 14,
        },

        signInText: {
            fontWeight: 'normal',
            fontSize: 18,
            color: Colors.black,
        },

        phoneNumberContainer: {
            flexDirection: "row",
            flex:1,
            marginTop: 23,
        },

        phoneNumberInputFiled: {
            flex:1,
            height: 50,
            borderWidth:1,
            borderColor: Colors.borderColor,
            borderBottomLeftRadius: 0,
            borderBottomRightRadius: 4,
            borderTopLeftRadius: 0,
            borderTopRightRadius: 4,
            paddingLeft: 15,
            fontSize: 15,
            borderLeftColor: Colors.white,
        },

        passwordInputFiled: {
            width: '100%',
            height: 50,
            marginTop: 24,
            borderWidth:1,
            borderColor: Colors.borderColor,
            borderRadius: 4,
            paddingLeft: 15,
            fontSize: 15,
        },

        forgetPasswordText: {
            fontWeight: 'normal',
            fontSize: 20,
            color: Colors.blueTextColor,
            marginTop: 22,
        },

        buttonView: {
            flexDirection: "row",
            justifyContent: "flex-end"
        },

        buttonStart: {
            width: 112,
            height: 40,
            marginTop: 11,
            backgroundColor: Colors.black,
            borderRadius: 4,
            justifyContent: 'center',
            alignItems: 'center',
        },

        buttonText: {
            fontWeight: 'normal',
            fontSize: 18,
            color: Colors.white
        },

        continueWithView: {
            marginTop: 29,
            justifyContent: "center",
            alignItems: "center",
        },

        continueWithText: {
            fontWeight: 'normal',
            fontSize: 20,
            color: Colors.lightGrayTextColor
        },

        googleButtonView: {
            marginTop: 16,
            justifyContent: "center",
            alignItems: "center",
        },

        googleButtonStart: {
            flexDirection: 'row',
            width: 112,
            height: 40,
            borderRadius: 1,
            justifyContent: 'center',
            alignItems: 'center',
            backgroundColor: Colors.lightGrayButtonColor,
        },

        googleText: {
            fontWeight: 'normal',
            fontSize: 18,
            color: Colors.black,
            paddingLeft: 10,
        },

        googleIcon: {
            width: 20,
            height: 20,
            justifyContent: 'center',
            alignItems: 'center',
        },

        createAccountView: {
            marginTop: 33,
            marginBottom: 22,
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
        },

        accountText: {
            fontSize: 20,
            justifyContent: 'center',
            alignItems: 'center',
            color: Colors.black,
        },

        createAccountText: {
            fontSize: 20,
            justifyContent: 'center',
            alignItems: 'center',
            color: Colors.blueTextColor,
        },
    });
}