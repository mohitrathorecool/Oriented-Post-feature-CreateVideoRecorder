import React from "react";
import { TouchableOpacity } from "react-native";
import { View, Text, TextInput, Image } from "react-native";
import { ImageBackground, SafeAreaView } from "react-native";
import { AppImages } from "../../Theme/AppImages";
import CustomCountryPicker from "../signup/CountryPicker";
import { CREATE, CREATE_ACCOUNT, DO_NOT_HAVE_ACCOUNT, ENTER_MOBILE_NUMBER, FORGET_PASSWORD, GOOGLE, LOGIN, OR_CONTINUE_WITH, PASSWORD } from "./constants";
import { useSignIn } from './hooks';

export default function (props:any) {

    const {
        themeStyles,
        onPressCreateAccount,
        onCreate,
        onPressForgetPassword,
        onPressGoogle,
    } = useSignIn(props);

    return(
        <SafeAreaView style={themeStyles.container}>
        {/* <Image 
            style={themeStyles.signUpViewBackground}
            ></ */}
            
            <ImageBackground style={{flex: 1,
            width: '100%',
            flex:0.56,
            resizeMode: 'stretch'}} 
            source={(AppImages.signupBackground)} />
            
            <View style={themeStyles.signInBottomView}>
                <View style={themeStyles.signInView}>
                    <Text style={themeStyles.signInText}> {LOGIN}</Text>
                    <View style={themeStyles.phoneNumberContainer}>
                        <CustomCountryPicker
                        />
                        <TextInput style={themeStyles.phoneNumberInputFiled}
                            placeholder={ENTER_MOBILE_NUMBER}
                            keyboardType="numeric"/>
                    </View>
                    <TextInput style={themeStyles.passwordInputFiled}
                            secureTextEntry={true}
                            placeholder={PASSWORD}/>
                    <Text style={themeStyles.forgetPasswordText}
                          onPress={onPressForgetPassword}> {FORGET_PASSWORD}</Text>
                    <View style = {themeStyles.buttonView}>
                        <TouchableOpacity style = {themeStyles.buttonStart}
                        onPress={onCreate}>
                            <Text style = {themeStyles.buttonText}>
                                {LOGIN}
                            </Text>
                        </TouchableOpacity>
                    </View>
                    <View style = {themeStyles.continueWithView}>
                        <Text style = {themeStyles.continueWithText}>
                                    {OR_CONTINUE_WITH}
                        </Text>
                    </View>
                    <View style = {themeStyles.googleButtonView}>
                        <TouchableOpacity style = {themeStyles.googleButtonStart}
                            onPress={onPressGoogle}>
                            <Image 
                                style={themeStyles.googleIcon}
                                source={(AppImages.googleIcon)}>
                            </Image>
                            <Text style = {themeStyles.googleText}>
                                {GOOGLE}
                            </Text>
                        </TouchableOpacity>
                    </View>
                    <View style = {themeStyles.createAccountView}>
                        <Text style = {themeStyles.accountText}>
                            {DO_NOT_HAVE_ACCOUNT}
                        </Text>
                        <Text style = {themeStyles.createAccountText}
                                onPress={onPressCreateAccount}>
                            {CREATE_ACCOUNT}
                        </Text>
                    </View>
                </View> 
            </View>
        </SafeAreaView>
    );
}