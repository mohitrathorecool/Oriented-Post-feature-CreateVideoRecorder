const AppImages = {
  mute: require('../Assets/Icons/mute.png'),
  volume: require('../Assets/Icons/volume.png'),
  more: require('../Assets/Icons/more.png'),
  heart: require('../Assets/Icons/heart.png'),
  comment: require('../Assets/Icons/comment.png'),
  share: require('../Assets/Icons/share.png'),
  user: require('../Assets/user.jpeg'),
  signupBackground: require('../Assets/signup_background.png'),
  googleIcon: require('../Assets/Icons/google_icon.png'),
  otpBackground: require('../Assets/otp_background.png'),
};

export {AppImages};
